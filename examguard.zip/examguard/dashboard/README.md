# Teacher dashboard (Milestone 3)

Vite + React + supabase-js. Teachers sign in with email and password (Supabase Auth). Host on Vercel or Netlify. See docs/PRD.md section 6.7.
