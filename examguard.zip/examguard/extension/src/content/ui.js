// Student-facing screens (rendered inside a closed Shadow DOM so Google Forms' CSS can't touch them).
//
//   EG_UI.show('consent' | 'incognito' | 'warning' | 'blurred' | 'locked' | 'fullscreen', props)
//   EG_UI.hide()
//   EG_UI.hud({strikes, max} | null)
//   EG_UI.toast('text')
//
// Each screen is one small function below. Restyle in styles.js; restructure markup here.

const EG_UI = (() => {
  let host, root, overlay, hud, toastEl, toastTimer;
  let current = null; // { screen, props } so the overlay can be rebuilt if the page removes it
  let hudState = null;

  const REASONS = {
    tab_switch: 'You switched to another tab.',
    tab_opened: 'You opened a new tab.',
    left_browser: 'You left the browser window.',
    other_window: 'You switched to another browser window.',
    navigated_away: 'You navigated away from the exam page.',
    exam_tab_closed: 'You closed the exam tab.',
    visibility_hidden: 'The exam page was hidden or minimised.'
  };

  function h(tag, attrs, ...kids) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (k === 'class') el.className = v;
      else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
      else if (v !== false && v != null) el.setAttribute(k, v);
    }
    kids.flat().forEach((c) => c != null && el.append(c));
    return el;
  }

  function ensure() {
    if (host && host.isConnected && root.contains(overlay)) return;
    if (host) host.remove(); // rebuild from scratch if the page or DevTools removed any part of it
    host = document.createElement('div');
    host.id = 'examguard-host';
    root = host.attachShadow({ mode: 'closed' });
    const style = document.createElement('style');
    style.textContent = EG_CSS;
    overlay = h('div', { class: 'eg-overlay', hidden: '' });
    hud = h('div', { class: 'eg-hud', hidden: '' });
    toastEl = h('div', { class: 'eg-toast', hidden: '' });
    root.append(style, overlay, hud, toastEl);
    document.documentElement.appendChild(host);
    if (current) render(current.screen, current.props);
    renderHud();
  }

  function setBlocking(on) {
    // inert = no clicks, no keyboard focus on the form underneath
    if (document.body) document.body.inert = !!on;
  }

  /* ------------------------------ screens ------------------------------ */

  function strikeDots(strikes, max) {
    return h('div', { class: 'eg-strikes' },
      Array.from({ length: max }, (_, i) => h('span', { class: 'eg-dot' + (i < strikes ? ' on' : '') })));
  }

  const screens = {
    // 1. Consent + start
    consent(p) {
      const nameInput = h('input', { class: 'eg-input', type: 'text', name: 'eg-name', placeholder: 'Full name', autocomplete: 'off' });
      const emailInput = h('input', { class: 'eg-input', type: 'email', name: 'eg-email', placeholder: 'you@school.edu', autocomplete: 'off', value: p.email || '' });
      const agree = h('input', { type: 'checkbox' });
      const err = h('p', { class: 'eg-error' }, p.error || '');
      const start = h('button', { class: 'eg-btn', disabled: '', onclick: () => p.onStart(nameInput.value, emailInput.value, err) }, 'Start exam');
      agree.addEventListener('change', () => (start.disabled = !agree.checked));
      const s = p.settings;
      return h('div', { class: 'eg-card' },
        h('div', { class: 'eg-icon' }, '\u{1F6E1}'),
        h('h1', { class: 'eg-title' }, p.title || 'Protected exam'),
        h('p', { class: 'eg-text' }, 'This exam is monitored by ExamGuard. Please read what is recorded before you begin.'),
        h('label', { class: 'eg-label' }, 'Your name'), nameInput,
        h('label', { class: 'eg-label' }, 'Your email'), emailInput,
        p.email ? h('p', { class: 'eg-text' }, 'Filled in from your Chrome profile.') : null,
        h('ul', { class: 'eg-list' },
          h('li', {}, 'Leaving this tab or window is recorded, with the site you open.'),
          s.mode === 'enforce' && s.snapBack ? h('li', {}, 'Other tabs are closed and you are returned to the exam.') : null,
          s.mode === 'enforce' && s.blockAiSites ? h('li', {}, 'AI and answer websites are blocked.') : null,
          s.mode === 'enforce' ? h('li', {}, `After ${s.maxStrikes} violations your exam is locked until your teacher unlocks it.`) : null,
          s.requireFullscreen ? h('li', {}, 'The exam runs in fullscreen.') : null,
          s.blockCopyPaste ? h('li', {}, 'Copy, paste and right-click are disabled.') : null),
        h('label', { class: 'eg-check' }, agree, h('span', {}, 'I understand and agree to be monitored during this exam.')),
        err, start);
    },

    // 2. Unsupported / incognito
    incognito() {
      return h('div', { class: 'eg-card' },
        h('div', { class: 'eg-icon danger' }, '!'),
        h('h1', { class: 'eg-title' }, 'This exam can’t start in a private window'),
        h('p', { class: 'eg-text' }, 'Open the exam link in a normal Chrome window, then try again.'));
    },

    // 4. Strike warning
    warning(p) {
      const secs = Math.max(1, Math.round((p.awayMs || 0) / 1000));
      return h('div', { class: 'eg-card' },
        h('div', { class: 'eg-icon warn' }, '!'),
        h('h1', { class: 'eg-title' }, 'Warning: you left the exam'),
        h('p', { class: 'eg-text' }, REASONS[p.reason] || 'Leaving the exam was detected.', ` (${secs}s away)`),
        strikeDots(p.strikes, p.max),
        h('p', { class: 'eg-text' }, 'This was recorded and your teacher can see it. ',
          h('strong', {}, `${p.max - p.strikes} more ${p.max - p.strikes === 1 ? 'violation' : 'violations'}`), ' will lock your exam.'),
        h('button', { class: 'eg-btn', onclick: p.onContinue }, 'Continue exam'));
    },

    // 5. Strike 2 blur
    blurred(p) {
      return h('div', { class: 'eg-card' },
        h('div', { class: 'eg-icon danger' }, '!'),
        h('h1', { class: 'eg-title' }, 'Final warning'),
        h('p', { class: 'eg-text' }, REASONS[p.reason] || 'Leaving the exam was detected.'),
        strikeDots(p.strikes, p.max),
        h('p', { class: 'eg-text' }, 'One more violation will ', h('strong', {}, 'lock your exam'), ' until your teacher approves.'),
        h('button', { class: 'eg-btn', onclick: p.onContinue }, 'Return to exam'));
    },

    // 6. Locked
    locked(p) {
      return h('div', { class: 'eg-card' },
        h('div', { class: 'eg-icon danger' }, '\u{1F512}'),
        h('h1', { class: 'eg-title' }, 'Your exam is paused'),
        h('p', { class: 'eg-text' }, 'Too many violations were recorded. Your teacher has been notified and must unlock your exam.'),
        strikeDots(p.strikes, p.max),
        h('div', { class: 'eg-row' }, h('div', { class: 'eg-spinner' }), h('span', { class: 'eg-text' }, 'Waiting for your teacher...')));
    },

    // 7. Fullscreen required
    fullscreen(p) {
      return h('div', { class: 'eg-card' },
        h('div', { class: 'eg-icon warn' }, '⛶'),
        h('h1', { class: 'eg-title' }, 'Return to fullscreen'),
        h('p', { class: 'eg-text' }, 'This exam must be taken in fullscreen. Your progress is saved.'),
        h('button', { class: 'eg-btn', onclick: p.onEnter }, 'Enter fullscreen'));
    }
  };

  /* ------------------------------ api ------------------------------ */

  function render(screen, props) {
    overlay.replaceChildren(screens[screen](props || {}));
    overlay.className = 'eg-overlay' + (screen === 'blurred' ? ' eg-blur' : '');
    overlay.hidden = false;
    setBlocking(true);
    const focusable = overlay.querySelector('input, button:not([disabled])');
    if (focusable) focusable.focus({ preventScroll: true });
  }

  function renderHud() {
    if (!hud) return;
    if (!hudState) { hud.hidden = true; return; }
    hud.replaceChildren(
      h('span', { class: 'eg-shield' }, '\u{1F6E1} Protected'),
      strikeDots(hudState.strikes, hudState.max));
    hud.hidden = false;
  }

  return {
    ensure,
    show(screen, props) {
      ensure();
      current = { screen, props };
      render(screen, props);
    },
    hide() {
      current = null;
      if (overlay) { overlay.hidden = true; overlay.replaceChildren(); }
      setBlocking(false);
    },
    isShowing: () => !!current,
    currentScreen: () => (current ? current.screen : null),
    host: () => host,
    // Called every 250ms by content.js. Restores anything removed or hidden from DevTools while an overlay should show.
    enforce() {
      if (!current) return;
      ensure();
      overlay.hidden = false;
      setBlocking(true);
    },
    focusPrimary() {
      const f = overlay && overlay.querySelector('input, button:not([disabled])');
      if (f) f.focus({ preventScroll: true });
    },
    hud(state) {
      hudState = state;
      ensure();
      renderHud();
    },
    toast(text) {
      ensure();
      toastEl.textContent = text;
      toastEl.hidden = false;
      clearTimeout(toastTimer);
      toastTimer = setTimeout(() => (toastEl.hidden = true), 2200);
    }
  };
})();
