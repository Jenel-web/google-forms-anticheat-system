# ExamGuard (step 1: extension skeleton)

Chrome extension (Manifest V3) that protects Google Forms exams. This is the **offline skeleton**: it uses a mock
backend in `chrome.storage`, so you can try everything without a server. Step 2 swaps in Supabase.

## Try it

1. Open `chrome://extensions`, turn on **Developer mode**, click **Load unpacked**, choose this folder.
2. Click the ExamGuard toolbar icon. Paste a Google Form link (the one you'd share with students, ending in
   `/viewform`), give it a title, press **Protect this form**.
3. Open that form link in a normal (non-incognito) tab. You'll get the consent screen. Enter your name and email, tick the box, **Start exam**.
4. Switch tabs, open a new tab, Alt+Tab to another app, press F12, copy/paste, exit fullscreen, or visit chatgpt.com.
   Watch the strikes: 1 = warning, 2 = blur/final warning, 3 = locked.
5. Open the popup and press **Unlock this student** (stands in for the teacher dashboard).

Tip: the popup is a good place to watch the event log. Opening the popup itself may register as a brief window switch.

## Layout

```
manifest.json
src/shared/constants.js        defaults, AI blocklist, form-URL parsing, strike ladder
src/background/background.js   service worker: sessions, leave-episodes, snap-back, AI blocking
src/background/backend.js      the ONE file to change when Supabase arrives
src/background/backend.mock.js offline stand-in (chrome.storage.local)
src/content/styles.js          ALL overlay styling (CSS variables at the top)
src/content/ui.js              student screens: consent, incognito, warning, blur, locked, fullscreen, HUD, toast
src/content/content.js         page monitoring: fullscreen, copy/paste, shortcuts, question tracking, heartbeat
src/blocked/                   "site blocked" page
src/popup/                     dev panel (temporary)
```

## How a violation works

Every way of leaving (tab switch, new tab, other window, leaving the browser, closing the exam tab, navigating away)
opens **one leave episode** and costs **one strike**. The episode closes when the exam tab is active and focused again.
The strike ladder is in `phaseForStrikes()`. In `record` mode nothing is blocked or shown; everything is logged.

## Known limits (by design of Chrome, not bugs)

- A browser extension **cannot** stop Alt+Tab to another application, a second device, or a phone. It detects and logs it.
- Question tracking reads Google Forms' unofficial page markup and may need updating if Google changes it.
- `/forms/d/e/<id>/viewform` (the shared link) and `/forms/d/<id>/viewform` (edit-id link) are different IDs for the same
  form; protect the link you actually give students.
- Session state is held in `chrome.storage.session`; quitting Chrome clears it. Step 2 stores attempts server-side so a
  restart resumes the same attempt.
- `<all_urls>` host permission is needed to redirect arbitrary blocked sites and read tab domains.

## Next steps

2. Supabase backend (Postgres + RLS + RPCs, anonymous student auth), same interface as `backend.js`.
3. Teacher dashboard (paste link, settings, live monitor).
4. Post-test report, integrity score, question heatmap.
