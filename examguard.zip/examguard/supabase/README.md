# Supabase (Milestone 2)

Run `supabase init` here, then create `migrations/0001_init.sql` from docs/PRD.md section 8 (tables, RLS, RPCs). Put pgTAP tests in `tests/`.

In the Supabase dashboard: enable **Email** auth for teachers and **Anonymous sign-ins** for students.
