// The single place the extension talks to a data store.
//
// Step 1 (now):  mock backend backed by chrome.storage.local, so everything can be tested offline.
// Step 2 (next): replace this export with backend.supabase.js, implementing the SAME methods.
//
//   Interface:
//     getTestByFormId(formId)            -> test | null
//     saveTest(test)                     -> test
//     createAttempt({testId, formId, student}) -> attemptId
//     patchAttempt(attemptId, patch)     -> void
//     appendEvent(event)                 -> void
//     heartbeat(attemptId)               -> void
//     onCommand(handler)                 -> void   (teacher commands, e.g. {type:'unlock', attemptId})
//
export { mockBackend as backend } from './backend.mock.js';
