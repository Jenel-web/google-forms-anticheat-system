// Shared helpers + defaults (ES module: used by the service worker and popup).

export const DEFAULT_SETTINGS = {
  mode: 'enforce',            // 'enforce' = warn/blur/lock + snap-back; 'record' = silent logging only
  maxStrikes: 3,              // 1 = warn, 2 = blur, 3 = lock (generalised in phaseForStrikes)
  snapBack: true,             // force focus back to exam tab, close stray tabs
  blockAiSites: true,         // redirect blocklisted domains to the "blocked" page
  blocklist: [],              // filled from DEFAULT_BLOCKLIST when a test is created
  allowlist: [],              // domains students may open (e.g. a calculator the teacher links)
  requireFullscreen: true,
  blockCopyPaste: true,
  logTabTitles: false         // log the tab title in addition to the domain (privacy: off by default)
};

export const DEFAULT_BLOCKLIST = [
  // AI assistants
  'chatgpt.com', 'chat.openai.com', 'openai.com',
  'gemini.google.com', 'bard.google.com', 'aistudio.google.com',
  'claude.ai', 'copilot.microsoft.com', 'perplexity.ai', 'poe.com',
  'deepseek.com', 'chat.deepseek.com', 'grok.com', 'x.ai',
  'character.ai', 'you.com', 'meta.ai', 'mistral.ai',
  // Homework / answer sites
  'brainly.com', 'chegg.com', 'coursehero.com', 'quizlet.com',
  'gauthmath.com', 'photomath.com', 'socratic.org', 'quillbot.com'
];

// Hosts the exam tab itself may legitimately visit (login, redirects, the form).
export const ALWAYS_ALLOWED_HOSTS = [
  'docs.google.com', 'accounts.google.com', 'forms.gle', 'forms.google.com', 'gstatic.com'
];

/**
 * Parse a Google Forms URL.
 * Handles /forms/d/e/<publishedId>/viewform, /forms/d/<editId>/viewform and /forms/u/1/d/e/...
 * Returns { id, kind: 'viewform'|'formResponse' } or null.
 */
export function parseFormId(url) {
  try {
    const u = new URL(url);
    if (u.hostname !== 'docs.google.com') return null;
    const m = u.pathname.match(/^\/forms\/(?:u\/\d+\/)?d\/(?:e\/)?([^/]+)\/(viewform|formResponse)/);
    return m ? { id: m[1], kind: m[2] } : null;
  } catch {
    return null;
  }
}

export function hostOf(url) {
  try {
    const u = new URL(url);
    if (u.protocol === 'chrome:' || u.protocol === 'chrome-search:') return `(${u.protocol}//${u.hostname})`;
    if (u.protocol === 'chrome-extension:') return '(extension)';
    return u.hostname.replace(/^www\./, '');
  } catch {
    return '';
  }
}

export function domainMatches(host, list) {
  if (!host) return false;
  return (list || []).some((d) => host === d || host.endsWith('.' + d));
}

/**
 * Strike ladder: 1 = warning, (max-1) = blur, max = locked.
 * With max=3 -> 1 warn, 2 blur, 3 lock.
 */
export function phaseForStrikes(strikes, max) {
  if (strikes >= max) return 'locked';
  if (strikes === max - 1 && strikes > 1) return 'blurred';
  return 'warning';
}
