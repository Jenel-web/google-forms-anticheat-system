// Offline stand-in for Supabase. Data lives in chrome.storage.local.
// Writes are serialised through a queue so concurrent read-modify-write calls never lose data.

const K = {
  tests: 'mock_tests',
  attempts: 'mock_attempts',
  events: 'mock_events',
  cmd: 'mock_command'
};
const MAX_EVENTS = 3000;

let queue = Promise.resolve();
function serial(fn) {
  const run = queue.then(() => fn());
  queue = run.catch(() => {});
  return run;
}

async function read(key, fallback) {
  const o = await chrome.storage.local.get(key);
  return o[key] ?? fallback;
}
const write = (key, value) => chrome.storage.local.set({ [key]: value });
const uid = (p) => p + '_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);

export const mockBackend = {
  async getTestByFormId(formId) {
    const tests = await read(K.tests, {});
    return tests[formId] || null;
  },

  saveTest(test) {
    return serial(async () => {
      const tests = await read(K.tests, {});
      const saved = { id: test.id || uid('test'), ...test };
      tests[saved.formId] = saved;
      await write(K.tests, tests);
      return saved;
    });
  },

  createAttempt({ testId, formId, student }) {
    return serial(async () => {
      const attempts = await read(K.attempts, {});
      const id = uid('att');
      attempts[id] = {
        id, testId, formId, student,
        status: 'active', strikes: 0,
        startedAt: Date.now(), lastHeartbeat: Date.now()
      };
      await write(K.attempts, attempts);
      return id;
    });
  },

  patchAttempt(id, patch) {
    return serial(async () => {
      const attempts = await read(K.attempts, {});
      if (!attempts[id]) return;
      attempts[id] = { ...attempts[id], ...patch };
      await write(K.attempts, attempts);
    });
  },

  appendEvent(ev) {
    return serial(async () => {
      const events = await read(K.events, []);
      events.push(ev);
      if (events.length > MAX_EVENTS) events.splice(0, events.length - MAX_EVENTS);
      await write(K.events, events);
    });
  },

  heartbeat(id) {
    return this.patchAttempt(id, { lastHeartbeat: Date.now() });
  },

  // Register ONCE at service-worker top level. handler({type, attemptId}).
  onCommand(handler) {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local' && changes[K.cmd]?.newValue) handler(changes[K.cmd].newValue);
    });
  },

  // ---- dev-only helpers (popup) ----
  sendCommand(cmd) {
    return write(K.cmd, { ...cmd, nonce: Date.now() + Math.random() });
  },
  async listAttempts() {
    return Object.values(await read(K.attempts, {})).sort((a, b) => b.startedAt - a.startedAt);
  },
  async listEvents(attemptId) {
    return (await read(K.events, [])).filter((e) => e.attemptId === attemptId);
  },
  async listTests() {
    return Object.values(await read(K.tests, {}));
  },
  async reset() {
    await chrome.storage.local.remove(Object.values(K));
  }
};
