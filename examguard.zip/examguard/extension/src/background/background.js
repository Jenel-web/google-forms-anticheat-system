// ExamGuard service worker.
//
// Core idea: a "leave episode". Any signal that the student left the exam (tab switch, new tab,
// other window, left the browser, exam tab closed, navigated away) opens ONE episode and costs ONE strike.
// The episode closes when the exam tab is active and its window focused again.
//
// MV3 service workers sleep, so all session state lives in chrome.storage.session and every
// mutation goes through withSessions() (a mutex) so near-simultaneous events can't race.

import { backend } from './backend.js';
import {
  DEFAULT_SETTINGS, DEFAULT_BLOCKLIST, ALWAYS_ALLOWED_HOSTS,
  parseFormId, hostOf, domainMatches, phaseForStrikes
} from '../shared/constants.js';

const KEY = 'eg_sessions';
const BLOCKED_PAGE = chrome.runtime.getURL('src/blocked/blocked.html');

/* ------------------------------------------------------------------ storage + mutex */

let chain = Promise.resolve();
function withSessions(fn) {
  const run = chain.then(async () => {
    const o = await chrome.storage.session.get(KEY);
    const all = o[KEY] || {};
    const result = await fn(all);
    await chrome.storage.session.set({ [KEY]: all });
    return result;
  });
  chain = run.catch((e) => console.error('[ExamGuard]', e));
  return run;
}

const live = (all) => Object.values(all).filter((s) => s.phase !== 'ended');
const byTab = (all, tabId) => live(all).find((s) => s.tabId === tabId);
const byAttempt = (all, id) => all[id];

/* ------------------------------------------------------------------ helpers */

function log(s, type, detail = {}) {
  const ev = { attemptId: s.id, t: Date.now(), type, q: s.q ?? null, ...detail };
  backend.appendEvent(ev).catch((e) => console.warn('appendEvent failed', e));
}
const patch = (s, p) => backend.patchAttempt(s.id, p).catch((e) => console.warn('patchAttempt failed', e));

function publicState(s) {
  return {
    phase: s.phase,
    strikes: s.strikes,
    maxStrikes: s.settings.maxStrikes,
    mode: s.settings.mode,
    requireFullscreen: s.settings.requireFullscreen,
    blockCopyPaste: s.settings.blockCopyPaste,
    studentName: s.student.name,
    lastReason: s.lastReason || null,
    lastAwayMs: s.lastAwayMs || 0,
    testTitle: s.testTitle
  };
}

function pushState(s) {
  if (s.tabId == null) return;
  chrome.tabs.sendMessage(s.tabId, { type: 'STATE', state: publicState(s) }).catch(() => {});
}

const getIdentity = () =>
  new Promise((resolve) => {
    try {
      chrome.identity.getProfileUserInfo({ accountStatus: 'ANY' }, (info) => resolve(info || {}));
    } catch {
      resolve({});
    }
  });

/* Allowlisted sites (teacher-approved, e.g. a calculator) are not a leave: they never open an episode,
   never count as a strike, and are never closed or snapped away from. Subdomains are included. */
const allowlisted = (s, url) => {
  const host = hostOf(url || '');
  return !!host && domainMatches(host, s.settings.allowlist);
};

/* A tab opened during the exam. Allowed sites are logged and left alone; anything else is one strike
   and, in enforce mode with snap-back on, closed immediately. */
async function handleNewTab(s, tabId, url, title) {
  const host = hostOf(url);
  if (allowlisted(s, url)) {
    log(s, 'allowed_tab_opened', { domain: host });
    return;
  }
  const enforce = s.settings.mode === 'enforce' && s.settings.snapBack;
  startEpisode(s, 'tab_opened', {
    domain: host || '(new tab)',
    closed: enforce,
    title: s.settings.logTabTitles ? (title || '').slice(0, 80) : undefined
  });
  if (enforce) {
    (s.closedTabs ||= []).push(tabId);
    s.closedTabs = s.closedTabs.slice(-20);
    await chrome.tabs.remove(tabId).catch(() => {});
    await snapBack(s);
    await maybeEndEpisode(s);
  }
}

/* ------------------------------------------------------------------ DNR blocklist */

async function syncBlockRules(all) {
  const domains = new Set();
  live(all).forEach((s) => {
    if (s.settings.mode !== 'enforce' || !s.settings.blockAiSites) return;
    s.settings.blocklist.forEach((d) => {
      // Allowlisted domains are never redirected, even if they also appear on the blocklist.
      // Limitation: an allowlist entry cannot carve a subdomain out of a blocked parent domain.
      if (!s.settings.allowlist.some((a) => d === a || d.endsWith('.' + a))) domains.add(d);
    });
  });
  const existing = await chrome.declarativeNetRequest.getSessionRules();
  const addRules = [...domains].map((d, i) => ({
    id: i + 1,
    priority: 1,
    action: { type: 'redirect', redirect: { extensionPath: `/src/blocked/blocked.html?site=${encodeURIComponent(d)}` } },
    condition: { urlFilter: `||${d}^`, resourceTypes: ['main_frame'] }
  }));
  await chrome.declarativeNetRequest.updateSessionRules({
    removeRuleIds: existing.map((r) => r.id),
    addRules
  });
}

/* ------------------------------------------------------------------ leave episodes */

function startEpisode(s, reason, detail = {}) {
  if (s.phase === 'ended') return;
  const now = Date.now();
  if (!s.episode) {
    s.episode = { start: now, reasons: [], domains: [] };
    if (s.phase !== 'locked') s.strikes += 1;
    s.lastReason = reason;
    log(s, 'strike', { strikes: s.strikes, reason });
    patch(s, { status: s.phase === 'locked' ? 'locked' : 'away', strikes: s.strikes });
  }
  s.episode.reasons.push(reason);
  if (detail.domain && !s.episode.domains.includes(detail.domain)) s.episode.domains.push(detail.domain);
  log(s, reason, detail);
}

async function isExamFocused(s) {
  if (s.tabId == null) return false;
  try {
    const [tab, win] = await Promise.all([chrome.tabs.get(s.tabId), chrome.windows.get(s.windowId)]);
    return tab.active && win.focused;
  } catch {
    return false;
  }
}

async function endEpisode(s) {
  if (!s.episode) return;
  const ep = s.episode;
  s.episode = null;
  s.lastAwayMs = Date.now() - ep.start;
  log(s, 'returned', { ms: s.lastAwayMs, reasons: ep.reasons, domains: ep.domains });
  if (s.settings.mode === 'enforce' && s.phase !== 'locked') {
    s.phase = phaseForStrikes(s.strikes, s.settings.maxStrikes);
    if (s.phase === 'locked') log(s, 'locked', { strikes: s.strikes });
  }
  patch(s, { status: s.phase === 'locked' ? 'locked' : s.phase === 'active' ? 'active' : 'warned', strikes: s.strikes });
  pushState(s);
}

async function maybeEndEpisode(s) {
  if (s.episode && (await isExamFocused(s))) await endEpisode(s);
}

async function snapBack(s) {
  if (s.settings.mode !== 'enforce' || !s.settings.snapBack || s.tabId == null) return;
  try {
    await chrome.windows.update(s.windowId, { focused: true, drawAttention: true });
    await chrome.tabs.update(s.tabId, { active: true });
  } catch (e) {
    /* window gone or OS refused focus: the episode will simply stay open until they return */
  }
}

async function endSession(all, s, reason) {
  log(s, reason);
  patch(s, { status: reason, endedAt: Date.now(), strikes: s.strikes });
  s.phase = 'ended';
  delete all[s.id];
  await syncBlockRules(all);
}

/* ------------------------------------------------------------------ browser events */

chrome.tabs.onActivated.addListener(({ tabId, windowId }) =>
  withSessions(async (all) => {
    for (const s of live(all)) {
      if (s.tabId == null || windowId !== s.windowId) continue;
      if (tabId !== s.tabId) {
        // Ignore activations of tabs we already closed (event ordering: created -> closed -> late "activated").
        if ((s.closedTabs || []).includes(tabId)) continue;
        // A blank new tab becomes active the moment it opens. It is decided at its first navigation, not here.
        if ((s.pendingTabs || []).includes(tabId)) continue;
        const tab = await chrome.tabs.get(tabId).catch(() => null);
        if (!tab) continue; // tab no longer exists
        const url = tab.url || tab.pendingUrl || '';
        if (allowlisted(s, url)) {
          log(s, 'allowed_site_viewed', { domain: hostOf(url) });
        } else {
          startEpisode(s, 'tab_switch', {
            domain: hostOf(url) || '(new tab)',
            title: s.settings.logTabTitles ? (tab.title || '').slice(0, 80) : undefined
          });
          await snapBack(s);
        }
      }
      await maybeEndEpisode(s);
    }
  })
);

chrome.tabs.onCreated.addListener((tab) =>
  withSessions(async (all) => {
    for (const s of live(all)) {
      if (tab.id === s.tabId) continue;
      const url = tab.pendingUrl || tab.url || '';
      if (!url || url === 'about:blank') {
        // URL not known yet: decide at the first real navigation (see onUpdated).
        (s.pendingTabs ||= []).push(tab.id);
        continue;
      }
      await handleNewTab(s, tab.id, url, tab.title);
    }
  })
);

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (!changeInfo.url && changeInfo.status !== 'complete') return;
  return withSessions(async (all) => {
    for (const s of live(all)) {
      // A new tab whose URL was not known at creation: decide now that we know where it went.
      if ((s.pendingTabs || []).includes(tabId)) {
        // Only a real navigation decides it. A "complete" status on a blank tab does not.
        if (!changeInfo.url || changeInfo.url === 'about:blank') continue;
        s.pendingTabs = s.pendingTabs.filter((id) => id !== tabId);
        await handleNewTab(s, tabId, changeInfo.url, tab.title);
        continue;
      }
      if (!changeInfo.url) continue;
      const url = changeInfo.url;
      if (tabId === s.tabId) {
        const info = parseFormId(url);
        if (info?.kind === 'formResponse') {
          await endSession(all, s, 'submitted');
          continue;
        }
        const host = hostOf(url);
        const ok = ALWAYS_ALLOWED_HOSTS.some((d) => host === d || host.endsWith('.' + d)) || domainMatches(host, s.settings.allowlist);
        if (!ok) {
          startEpisode(s, 'navigated_away', { domain: host });
          if (s.settings.mode === 'enforce' && s.settings.snapBack) await chrome.tabs.goBack(tabId).catch(() => {});
          await maybeEndEpisode(s);
        }
      } else if (s.episode) {
        // Another tab navigated while the student is "away": record where they went.
        if (url.startsWith(BLOCKED_PAGE)) {
          const site = new URL(url).searchParams.get('site');
          log(s, 'blocked_site_attempt', { domain: site });
          if (site && !s.episode.domains.includes(site)) s.episode.domains.push(site);
        } else {
          const host = hostOf(url);
          if (host) {
            log(s, 'tab_navigated', { domain: host, blocked: domainMatches(host, s.settings.blocklist) });
            if (!s.episode.domains.includes(host)) s.episode.domains.push(host);
          }
        }
      }
    }
  });
});

chrome.tabs.onRemoved.addListener((tabId) =>
  withSessions(async (all) => {
    const s = byTab(all, tabId);
    if (!s) return;
    startEpisode(s, 'exam_tab_closed');
    s.tabId = null; // orphan: a reopened form for the same test resumes this session (strikes kept)
  })
);

chrome.windows.onFocusChanged.addListener((windowId) =>
  withSessions(async (all) => {
    for (const s of live(all)) {
      if (s.tabId == null) continue;
      if (windowId === chrome.windows.WINDOW_ID_NONE) {
        startEpisode(s, 'left_browser');
        await snapBack(s);
      } else if (windowId === s.windowId) {
        await maybeEndEpisode(s);
      } else {
        const [active] = await chrome.tabs.query({ windowId, active: true }).catch(() => []);
        const url = active ? (active.url || active.pendingUrl || '') : '';
        if (active && allowlisted(s, url)) {
          log(s, 'allowed_site_viewed', { domain: hostOf(url), window: true });
        } else {
          startEpisode(s, 'other_window', { domain: hostOf(url) || '(unknown)' });
          await snapBack(s);
        }
      }
    }
  })
);

chrome.idle.setDetectionInterval(60);
chrome.idle.onStateChanged.addListener((state) =>
  withSessions(async (all) => {
    for (const s of live(all)) log(s, state === 'active' ? 'idle_end' : `idle_${state}`);
  })
);

/* ------------------------------------------------------------------ teacher commands */

backend.onCommand((cmd) =>
  withSessions(async (all) => {
    const s = byAttempt(all, cmd.attemptId);
    if (!s) return;
    if (cmd.type === 'unlock' && s.phase === 'locked') {
      s.phase = 'active';
      s.strikes = Math.max(0, s.settings.maxStrikes - 1); // next violation locks again
      log(s, 'unlocked');
      patch(s, { status: 'active', strikes: s.strikes });
      pushState(s);
    }
  })
);

/* ------------------------------------------------------------------ messages from content script / popup */

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  handle(msg, sender)
    .then(sendResponse)
    .catch((e) => {
      console.error('[ExamGuard]', e);
      sendResponse({ error: String(e && e.message ? e.message : e) });
    });
  return true;
});

async function handle(msg, sender) {
  const tab = sender.tab;
  switch (msg.type) {
    case 'PAGE_LOADED':
      return onPageLoaded(msg, tab);
    case 'START_EXAM':
      return onStartExam(msg, tab);
    case 'EVENT':
    case 'QUESTION':
    case 'HEARTBEAT':
    case 'ACK':
      return withSessions(async (all) => {
        const s = tab && byTab(all, tab.id);
        if (!s) return { ok: false };
        if (msg.type === 'QUESTION') {
          s.q = msg.q;
          log(s, 'question_changed', { q: msg.q });
        } else if (msg.type === 'HEARTBEAT') {
          s.lastHeartbeat = Date.now();
          backend.heartbeat(s.id).catch(() => {});
        } else if (msg.type === 'ACK') {
          if (s.phase === 'warning' || s.phase === 'blurred') {
            s.phase = 'active';
            log(s, 'ack');
            patch(s, { status: 'active' });
          }
          return { ok: true, state: publicState(s) };
        } else {
          log(s, msg.kind, msg.detail || {});
          if (msg.kind === 'visibility_hidden') startEpisode(s, 'visibility_hidden');
          if (msg.kind === 'visibility_visible') await maybeEndEpisode(s);
        }
        return { ok: true };
      });
    case 'DEV_STATE':
      return devState();
    case 'DEV_ADD_TEST':
      return devAddTest(msg);
    case 'DEV_UNLOCK':
      await backend.sendCommand({ type: 'unlock', attemptId: msg.attemptId });
      return { ok: true };
    case 'DEV_RESET':
      await backend.reset();
      await withSessions(async (all) => {
        Object.keys(all).forEach((k) => delete all[k]);
        await syncBlockRules(all);
      });
      return { ok: true };
    default:
      return { error: 'unknown message' };
  }
}

async function onPageLoaded(msg, tab) {
  const info = parseFormId(msg.url);
  if (!info || !tab) return { protected: false };

  return withSessions(async (all) => {
    let s = byTab(all, tab.id) || live(all).find((x) => x.tabId == null && x.formId === info.id);

    if (info.kind === 'formResponse') {
      if (s) await endSession(all, s, 'submitted');
      return { protected: false };
    }

    if (s) {
      // Reload or re-opened tab: resume without a new consent, keep strikes.
      const rebound = s.tabId !== tab.id;
      s.tabId = tab.id;
      s.windowId = tab.windowId;
      log(s, rebound ? 'tab_reopened' : 'page_reload');
      await endEpisode(s);
      return { protected: true, resume: true, state: publicState(s) };
    }

    const test = await backend.getTestByFormId(info.id);
    if (!test) return { protected: false };
    const identity = await getIdentity();
    return {
      protected: true,
      resume: false,
      test: { title: test.title, settings: { ...DEFAULT_SETTINGS, ...test.settings } },
      identity: { email: identity.email || null },
      incognito: !!tab.incognito
    };
  });
}

async function onStartExam(msg, tab) {
  const info = parseFormId(msg.url);
  if (!info || !tab) return { error: 'NOT_A_FORM' };
  if (tab.incognito) return { error: 'INCOGNITO' };
  const name = (msg.name || '').trim().slice(0, 100);
  if (!name) return { error: 'NAME_REQUIRED' };
  const email = (msg.email || '').trim().toLowerCase().slice(0, 200);
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return { error: 'EMAIL_REQUIRED' };

  return withSessions(async (all) => {
    if (byTab(all, tab.id)) return { state: publicState(byTab(all, tab.id)) };
    const test = await backend.getTestByFormId(info.id);
    if (!test) return { error: 'NOT_PROTECTED' };

    const identity = await getIdentity();
    // Students type name + email (no sign-in). "verified" = typed email matches the Chrome profile email.
    const chromeEmail = (identity.email || '').toLowerCase() || null;
    const student = { name, email, chromeEmail, verified: !!chromeEmail && chromeEmail === email };
    const settings = { ...DEFAULT_SETTINGS, ...test.settings };
    const attemptId = await backend.createAttempt({ testId: test.id, formId: info.id, student });

    const s = {
      id: attemptId, testId: test.id, testTitle: test.title, formId: info.id,
      tabId: tab.id, windowId: tab.windowId,
      student, settings,
      phase: 'active', strikes: 0, episode: null,
      q: null, startedAt: Date.now(), lastHeartbeat: Date.now()
    };
    all[s.id] = s;
    log(s, 'session_start', { verified: student.verified });
    log(s, 'consent_accepted');
    await syncBlockRules(all);
    return { state: publicState(s) };
  });
}

/* ------------------------------------------------------------------ dev helpers (popup) */

async function devState() {
  const sessions = await withSessions(async (all) => live(all).map((s) => ({ ...publicState(s), id: s.id, tabId: s.tabId, student: s.student })));
  const attempts = await backend.listAttempts();
  const latest = attempts[0];
  const events = latest ? (await backend.listEvents(latest.id)).slice(-40).reverse() : [];
  return { sessions, latest, events, tests: await backend.listTests() };
}

async function devAddTest({ url, title, settings }) {
  const info = parseFormId(url);
  if (!info) return { error: 'That does not look like a Google Forms link.' };
  const test = await backend.saveTest({
    formId: info.id,
    title: title || 'Untitled exam',
    settings: { ...DEFAULT_SETTINGS, blocklist: DEFAULT_BLOCKLIST, ...(settings || {}) }
  });
  return { ok: true, test };
}
