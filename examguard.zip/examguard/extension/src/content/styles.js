// All visual styling for the in-page overlays lives here.
// Re-skin the whole student experience by editing the :host variables below (colors, radius, fonts).
// This string is injected into a Shadow DOM, so it can't clash with Google Forms' own CSS.

const EG_CSS = `
:host { all: initial; }

.eg-root, .eg-overlay, .eg-hud, .eg-toast {
  /* ---- THEME TOKENS: edit these to match your design ---- */
  --eg-font: "Google Sans", "Segoe UI", system-ui, -apple-system, Roboto, sans-serif;
  --eg-bg: #ffffff;
  --eg-backdrop: rgba(16, 20, 28, 0.88);
  --eg-text: #1f2430;
  --eg-muted: #5b6475;
  --eg-primary: #5b3df5;
  --eg-primary-text: #ffffff;
  --eg-warn: #d98a00;
  --eg-danger: #d93025;
  --eg-ok: #188038;
  --eg-border: #e3e6ee;
  --eg-radius: 16px;
  --eg-shadow: 0 24px 64px rgba(0, 0, 0, 0.35);
  font-family: var(--eg-font);
  color: var(--eg-text);
  box-sizing: border-box;
}
*, *::before, *::after { box-sizing: inherit; }

/* ---------- full-page overlay ---------- */
.eg-overlay {
  position: fixed; inset: 0; z-index: 2147483647;
  display: flex; align-items: center; justify-content: center;
  background: var(--eg-backdrop); padding: 24px; overflow: auto;
}
.eg-overlay[hidden], .eg-hud[hidden], .eg-toast[hidden] { display: none; }
.eg-overlay.eg-blur { backdrop-filter: blur(22px); -webkit-backdrop-filter: blur(22px); background: rgba(16, 20, 28, 0.6); }

.eg-card {
  width: min(520px, 100%); background: var(--eg-bg);
  border-radius: var(--eg-radius); box-shadow: var(--eg-shadow);
  padding: 32px; display: flex; flex-direction: column; gap: 16px;
}
.eg-icon {
  width: 48px; height: 48px; border-radius: 50%;
  display: grid; place-items: center; font-size: 24px; font-weight: 700;
  background: #eceafe; color: var(--eg-primary);
}
.eg-icon.warn   { background: #fff3d6; color: var(--eg-warn); }
.eg-icon.danger { background: #fde7e5; color: var(--eg-danger); }
.eg-title { margin: 0; font-size: 22px; font-weight: 600; line-height: 1.25; }
.eg-text  { margin: 0; font-size: 15px; line-height: 1.5; color: var(--eg-muted); }
.eg-text strong { color: var(--eg-text); }

.eg-list { margin: 0; padding: 0 0 0 20px; font-size: 14px; line-height: 1.6; color: var(--eg-muted); }
.eg-box  { background: #f6f7fb; border: 1px solid var(--eg-border); border-radius: 12px; padding: 12px 14px; font-size: 14px; }
.eg-row  { display: flex; align-items: center; gap: 8px; }
.eg-label { font-size: 13px; font-weight: 600; color: var(--eg-text); }

.eg-input {
  width: 100%; font: inherit; font-size: 15px; padding: 11px 12px;
  border: 1px solid var(--eg-border); border-radius: 10px; color: var(--eg-text); background: #fff;
}
.eg-input:focus { outline: 2px solid var(--eg-primary); outline-offset: 1px; }
.eg-check { display: flex; gap: 10px; align-items: flex-start; font-size: 14px; color: var(--eg-muted); line-height: 1.4; }
.eg-error { color: var(--eg-danger); font-size: 13px; min-height: 1em; margin: 0; }

.eg-btn {
  font: inherit; font-size: 15px; font-weight: 600; cursor: pointer;
  border: 0; border-radius: 10px; padding: 12px 18px;
  background: var(--eg-primary); color: var(--eg-primary-text);
}
.eg-btn:disabled { opacity: .45; cursor: not-allowed; }
.eg-btn.secondary { background: #eef0f6; color: var(--eg-text); }

.eg-strikes { display: flex; gap: 6px; }
.eg-dot { width: 12px; height: 12px; border-radius: 50%; background: var(--eg-border); }
.eg-dot.on { background: var(--eg-danger); }

.eg-spinner {
  width: 18px; height: 18px; border-radius: 50%;
  border: 3px solid var(--eg-border); border-top-color: var(--eg-primary);
  animation: eg-spin 1s linear infinite;
}
@keyframes eg-spin { to { transform: rotate(360deg); } }

/* ---------- HUD badge ---------- */
.eg-hud {
  position: fixed; top: 12px; right: 12px; z-index: 2147483646;
  display: flex; align-items: center; gap: 10px;
  background: rgba(255,255,255,.96); border: 1px solid var(--eg-border);
  border-radius: 999px; padding: 6px 12px; font-size: 13px; font-weight: 600;
  box-shadow: 0 4px 16px rgba(0,0,0,.12);
}
.eg-hud .eg-shield { color: var(--eg-ok); }

/* ---------- toast ---------- */
.eg-toast {
  position: fixed; bottom: 24px; left: 50%; transform: translateX(-50%);
  z-index: 2147483646; background: #1f2430; color: #fff;
  padding: 10px 16px; border-radius: 10px; font-size: 14px;
}
`;
