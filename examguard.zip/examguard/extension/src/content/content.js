// ExamGuard content script: runs on Google Forms pages.
// It asks the service worker whether this form is protected, shows consent/overlays,
// and reports in-page signals (fullscreen, copy/paste, shortcuts, current question, heartbeat).

(() => {
  if (window.top !== window) return;

  let state = null;       // latest session state pushed from the service worker
  let monitoring = false;

  /* ------------------------------ messaging ------------------------------ */

  async function send(msg) {
    try {
      return await chrome.runtime.sendMessage(msg);
    } catch (e) {
      return null; // extension reloaded/disabled: nothing we can do from here
    }
  }
  const report = (kind, detail) => send({ type: 'EVENT', kind, detail });

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg && msg.type === 'STATE') applyState(msg.state);
  });

  /* ------------------------------ input guard ------------------------------ */
  // The overlay alone is not a lock: DevTools can remove it, hide it, or clear body.inert.
  // While an overlay should be showing, this window-level capture listener stops all input that does
  // not come from the overlay itself. It doesn't depend on the page DOM, so tampering with the DOM
  // doesn't weaken it. Submits are blocked and logged; any other blocked input is logged (throttled).
  const GUARDED_EVENTS = ['click', 'mousedown', 'mouseup', 'pointerdown', 'pointerup', 'touchstart', 'touchend',
    'keydown', 'keyup', 'keypress', 'submit', 'input', 'change', 'dragstart', 'drop'];
  let lastBlockedReport = 0;
  const fromOverlay = (e) => {
    const host = EG_UI.host();
    return !!host && e.composedPath().includes(host);
  };
  function guard(e) {
    if (!EG_UI.isShowing() || fromOverlay(e)) return;
    e.preventDefault();
    e.stopImmediatePropagation();
    e.stopPropagation();
    if (e.type === 'submit') {
      report('submit_while_blocked', { screen: EG_UI.currentScreen(), phase: state && state.phase });
    } else if (Date.now() - lastBlockedReport > 1000) {
      lastBlockedReport = Date.now();
      report('input_while_blocked', { inputType: e.type, screen: EG_UI.currentScreen() }); // never a `type` key: it would overwrite the event type
    }
  }
  GUARDED_EVENTS.forEach((t) => window.addEventListener(t, guard, true));
  window.addEventListener('focusin', (e) => {
    if (EG_UI.isShowing() && !fromOverlay(e)) EG_UI.focusPrimary();
  }, true);
  // Restore the overlay and body.inert every 250ms if they were removed or changed. No-op when nothing is showing.
  setInterval(() => EG_UI.enforce(), 250);

  /* ------------------------------ boot ------------------------------ */

  (async () => {
    const res = await send({ type: 'PAGE_LOADED', url: location.href });
    if (!res || !res.protected) return;
    if (res.resume) {
      applyState(res.state);
      startMonitoring();
    } else if (res.incognito) {
      EG_UI.show('incognito');
    } else {
      showConsent(res);
    }
  })();

  function showConsent(res) {
    const props = {
      title: res.test.title,
      email: res.identity && res.identity.email,
      settings: res.test.settings,
      onStart(name, email, errEl) {
        if (!name.trim()) { errEl.textContent = 'Please enter your name.'; return; }
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) { errEl.textContent = 'Please enter a valid email.'; return; }
        errEl.textContent = '';
        // requestFullscreen must be called inside the click handler (user gesture).
        const fs = res.test.settings.requireFullscreen
          ? document.documentElement.requestFullscreen().catch(() => {})
          : Promise.resolve();
        fs.then(async () => {
          const r = await send({ type: 'START_EXAM', url: location.href, name, email });
          if (!r || r.error) {
            errEl.textContent = !r ? 'Could not reach ExamGuard. Reload the page.' :
              r.error === 'INCOGNITO' ? 'Private windows are not allowed.' :
              r.error === 'EMAIL_REQUIRED' ? 'Please enter a valid email.' : 'Could not start: ' + r.error;
            return;
          }
          applyState(r.state);
          startMonitoring();
        });
      }
    };
    EG_UI.show('consent', props);
  }

  /* ------------------------------ state -> UI ------------------------------ */

  const enforce = () => !!state && state.mode === 'enforce';
  const inFullscreen = () => !!document.fullscreenElement;

  function applyState(next) {
    state = next;
    if (!state) return;
    EG_UI.hud(enforce() ? { strikes: state.strikes, max: state.maxStrikes } : null);

    const common = { strikes: state.strikes, max: state.maxStrikes, reason: state.lastReason, awayMs: state.lastAwayMs };
    if (state.phase === 'locked') {
      EG_UI.show('locked', common);
    } else if (state.phase === 'blurred') {
      EG_UI.show('blurred', { ...common, onContinue: acknowledge });
    } else if (state.phase === 'warning') {
      EG_UI.show('warning', { ...common, onContinue: acknowledge });
    } else {
      showFullscreenIfNeeded();
    }
  }

  async function acknowledge() {
    const r = await send({ type: 'ACK' });
    if (r && r.state) applyState(r.state);
  }

  function showFullscreenIfNeeded() {
    if (state && state.phase === 'active' && state.requireFullscreen && enforce() && !inFullscreen()) {
      EG_UI.show('fullscreen', {
        onEnter: () => document.documentElement.requestFullscreen().catch(() => {})
      });
    } else if (state && state.phase === 'active') {
      EG_UI.hide();
    }
  }

  /* ------------------------------ monitoring ------------------------------ */

  function startMonitoring() {
    if (monitoring) return;
    monitoring = true;

    // Heartbeat: the dashboard flags a student whose heartbeat stops (extension disabled, offline).
    setInterval(() => send({ type: 'HEARTBEAT', fullscreen: inFullscreen() }), 5000);

    document.addEventListener('visibilitychange', () =>
      report(document.hidden ? 'visibility_hidden' : 'visibility_visible'));

    document.addEventListener('fullscreenchange', () => {
      if (inFullscreen()) {
        report('fullscreen_enter');
        if (state && state.phase === 'active') showFullscreenIfNeeded();
      } else {
        report('fullscreen_exit');
        if (state && state.requireFullscreen) showFullscreenIfNeeded();
      }
    });

    // Copy / cut / paste / right-click
    const lastLogged = {};
    ['copy', 'cut', 'paste', 'contextmenu'].forEach((type) =>
      document.addEventListener(type, (e) => {
        if (!state || !state.blockCopyPaste) return;
        const now = Date.now();
        if (!lastLogged[type] || now - lastLogged[type] > 1000) {
          lastLogged[type] = now;
          report(type === 'contextmenu' ? 'contextmenu_attempt' : `${type}_attempt`);
          if (enforce()) EG_UI.toast(type === 'contextmenu' ? 'Right-click is disabled during the exam.' : 'Copy and paste are disabled during the exam.');
        }
        if (enforce()) { e.preventDefault(); e.stopPropagation(); }
      }, true));

    // DevTools / view-source / print / save shortcuts (best effort - the browser may still handle some).
    document.addEventListener('keydown', (e) => {
      if (!state) return;
      const mod = e.ctrlKey || e.metaKey;
      const k = e.key.toLowerCase();
      const hit = e.key === 'F12' ||
        (mod && e.shiftKey && ['i', 'j', 'c'].includes(k)) ||
        (mod && ['u', 'p', 's'].includes(k));
      if (hit) {
        report('shortcut_blocked', { key: (mod ? 'Ctrl+' : '') + (e.shiftKey ? 'Shift+' : '') + e.key });
        if (enforce()) { e.preventDefault(); e.stopPropagation(); }
      }
    }, true);
    document.addEventListener('keyup', (e) => {
      if (e.key === 'PrintScreen') report('printscreen');
    }, true);

    // Which question is the student on? Best effort: Google Forms' markup is unofficial and can change.
    let lastQ = '';
    const trackQuestion = () => {
      const items = [...document.querySelectorAll('div[role="listitem"]')];
      if (!items.length) return;
      const mid = window.innerHeight / 2;
      let best = 0, bestD = Infinity;
      items.forEach((el, i) => {
        const r = el.getBoundingClientRect();
        const d = Math.abs((r.top + r.bottom) / 2 - mid);
        if (d < bestD) { bestD = d; best = i; }
      });
      const key = `${best + 1}/${items.length}`;
      if (key !== lastQ) {
        lastQ = key;
        send({ type: 'QUESTION', q: { i: best + 1, n: items.length } });
      }
    };
    setInterval(trackQuestion, 1500);
    window.addEventListener('scroll', () => trackQuestion(), { passive: true });
  }
})();
