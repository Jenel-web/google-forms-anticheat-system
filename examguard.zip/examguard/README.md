# ExamGuard

Anti-cheat companion for Google Forms exams. A Chrome extension logs and blocks tab switching and AI sites, a Supabase backend stores the data, and a teacher dashboard shows it.

- Requirements: [`docs/PRD.md`](docs/PRD.md)
- Guide for Claude Code and contributors: [`CLAUDE.md`](CLAUDE.md)
- Extension quick start: [`extension/README.md`](extension/README.md)

Status: Milestone 1 (the extension skeleton) is done. Next up is Milestone 2, the Supabase backend.
