"""
ExamGuard end-to-end test (Milestone 1).

Loads ../../extension into Chromium, fakes a Google Form via request routing, and exercises:
consent -> start -> new tab (strike 1, warning) -> tab switch (strike 2, blur) -> tab switch (strike 3, lock)
-> teacher unlock -> DNR rules present -> copy attempt logged -> submit ends session and removes rules.

Run:   pip install playwright && python tests/e2e/run_e2e.py
Env:   CHROME_PATH=/path/to/chrome   (optional; otherwise Playwright's "chromium" channel)

Note: the overlay uses a CLOSED shadow root in production. The test copies the extension to a temp dir
and patches it to 'open' so Playwright can click inside it. Never ship that patch.
"""
import asyncio, os, shutil, sys, tempfile
from pathlib import Path
from playwright.async_api import async_playwright

ROOT = Path(__file__).resolve().parents[2]
EXT_SRC = ROOT / "extension"
FORM = "https://docs.google.com/forms/d/e/TESTFORM123/viewform"
FORM_DONE = "https://docs.google.com/forms/d/e/TESTFORM123/formResponse"
HTML = "<!doctype html><html><body><div role='list'>" + "".join(
    f"<div role='listitem' style='height:500px'><h3>Question {i}</h3><input type='text'></div>" for i in range(1, 6)
) + "</div></body></html>"

failures = []
def check(name, cond, extra=""):
    print(("PASS " if cond else "FAIL ") + name + (f"  [{extra}]" if extra else ""))
    if not cond:
        failures.append(name)

FORM2 = "https://docs.google.com/forms/d/e/TESTFORM456/viewform"
FORM2_DONE = "https://docs.google.com/forms/d/e/TESTFORM456/formResponse"
ALLOWED = "https://allowed.test/calculator"
OTHER = "https://other.test/page"

async def allowlist_test(ctx, dev, state, sessions):
    """Allowlisted sites are not strikes and are not closed; other sites still are."""
    print("-- allowlist")
    async def serve_site(route):
        await route.fulfill(status=200, content_type="text/html", body="<!doctype html><title>site</title><p>site</p>")
    await ctx.route("https://allowed.test/**", serve_site)
    await ctx.route("https://other.test/**", serve_site)

    r = await dev({"type": "DEV_ADD_TEST", "url": FORM2, "title": "Calculator Exam",
                   "settings": {"requireFullscreen": False, "allowlist": ["allowed.test"]}})
    check("protect form 2 with allowlist", r.get("ok"), r.get("error", ""))

    exam = await ctx.new_page()
    await exam.goto(FORM2)
    await exam.wait_for_selector("#examguard-host", state="attached", timeout=8000)
    await exam.fill("#examguard-host input[name=eg-name]", "Calc Student")
    await exam.fill("#examguard-host input[name=eg-email]", "calc@school.edu")
    await exam.check("#examguard-host input[type=checkbox]")
    await exam.click("text=Start exam")
    await asyncio.sleep(1)

    allowed = await ctx.new_page()
    await allowed.goto(ALLOWED)
    await asyncio.sleep(1.5)
    check("allowlisted tab stays open", not allowed.is_closed())
    await allowed.bring_to_front(); await asyncio.sleep(1)
    await exam.bring_to_front(); await asyncio.sleep(1)
    st = await state()
    check("allowlisted tab switches are not strikes", sessions(st) == [("active", 0)], sessions(st))

    other = await ctx.new_page()
    try:
        await other.goto(OTHER, timeout=5000)  # the extension closes this tab as soon as it navigates
    except Exception:
        pass
    await asyncio.sleep(1.5)
    await exam.bring_to_front(); await asyncio.sleep(1)
    st = await state()
    check("non-allowlisted tab is still a strike", sessions(st) == [("warning", 1)], sessions(st))
    check("non-allowlisted tab is still closed", other.is_closed())
    await exam.click("text=Continue exam"); await asyncio.sleep(.5)

    ev_types = [e["type"] for e in (await state())["events"]]
    check("allowed tab opening is logged", "allowed_tab_opened" in ev_types)
    check("allowed site viewing is logged", "allowed_site_viewed" in ev_types)

    await exam.goto(FORM2_DONE); await asyncio.sleep(1)
    st = await state()
    check("allowlist session ends on submit", len(st["sessions"]) == 0)
    await allowed.close()

async def main():
    tmp = Path(tempfile.mkdtemp(prefix="examguard-e2e-"))
    ext = tmp / "ext"
    shutil.copytree(EXT_SRC, ext)
    ui = ext / "src/content/ui.js"
    ui.write_text(ui.read_text().replace("mode: 'closed'", "mode: 'open'"))

    async with async_playwright() as p:
        kwargs = dict(
            headless=False,
            args=["--headless=new", f"--disable-extensions-except={ext}", f"--load-extension={ext}", "--no-sandbox"],
        )
        if os.environ.get("CHROME_PATH"):
            kwargs["executable_path"] = os.environ["CHROME_PATH"]
        else:
            kwargs["channel"] = "chromium"
        ctx = await p.chromium.launch_persistent_context(str(tmp / "profile"), **kwargs)
        try:
            sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker")
            ext_id = sw.url.split("/")[2]

            async def serve_form(route):
                await route.fulfill(status=200, content_type="text/html", body=HTML)
            await ctx.route("https://docs.google.com/forms/**", serve_form)

            pop = await ctx.new_page()
            await pop.goto(f"chrome-extension://{ext_id}/src/popup/popup.html")
            dev = lambda msg: pop.evaluate("(m) => chrome.runtime.sendMessage(m)", msg)
            state = lambda: dev({"type": "DEV_STATE"})
            sessions = lambda st: [(s["phase"], s["strikes"]) for s in st["sessions"]]

            await allowlist_test(ctx, dev, state, sessions)

            r = await dev({"type": "DEV_ADD_TEST", "url": FORM, "title": "Demo Exam", "settings": {"requireFullscreen": False}})
            check("protect form", r.get("ok"), r.get("error", ""))

            exam = await ctx.new_page()
            await exam.goto(FORM)
            await exam.wait_for_selector("#examguard-host", state="attached", timeout=8000)
            check("consent screen shown", await exam.locator("text=Start exam").count() > 0)
            await exam.fill("#examguard-host input[name=eg-name]", "Test Student")
            # invalid email must be rejected
            await exam.fill("#examguard-host input[name=eg-email]", "not-an-email")
            await exam.check("#examguard-host input[type=checkbox]")
            await exam.click("text=Start exam")
            await asyncio.sleep(.5)
            check("invalid email rejected", await exam.locator("text=Please enter a valid email.").count() > 0)
            await exam.fill("#examguard-host input[name=eg-email]", "student@school.edu")
            await exam.check("#examguard-host input[type=checkbox]")
            await exam.click("text=Start exam")
            await asyncio.sleep(1)
            st = await state()
            check("session active, 0 strikes", sessions(st) == [("active", 0)], sessions(st))

            # Strike 1: open a new tab -> extension closes it
            before = len(ctx.pages)
            try:
                nt = await ctx.new_page()
                await nt.goto(OTHER, timeout=5000)  # navigating decides the tab; the extension closes it
            except Exception:
                pass  # closed by the extension before Playwright could finish
            await asyncio.sleep(1.5)
            await exam.bring_to_front(); await asyncio.sleep(1)
            st = await state()
            check("new tab closed", len(ctx.pages) == before, f"{before}->{len(ctx.pages)}")
            check("strike 1 = warning", sessions(st) == [("warning", 1)], sessions(st))
            await exam.click("text=Continue exam"); await asyncio.sleep(.5)

            # Strike 2: switch to another existing tab
            await pop.bring_to_front(); await asyncio.sleep(1.2)
            await exam.bring_to_front(); await asyncio.sleep(1.2)
            st = await state()
            check("strike 2 = blurred", sessions(st) == [("blurred", 2)], sessions(st))
            check("final warning visible", await exam.locator("text=Final warning").count() > 0)
            await exam.click("text=Return to exam"); await asyncio.sleep(.5)

            # Strike 3: lock
            await pop.bring_to_front(); await asyncio.sleep(1.2)
            await exam.bring_to_front(); await asyncio.sleep(1.2)
            st = await state()
            check("strike 3 = locked", sessions(st) == [("locked", 3)], sessions(st))

            # Lock bypass: remove the overlay, clear body.inert and click a control underneath, all synchronously.
            bypass = await exam.evaluate("""() => {
              window.__submitted = false;
              const b = document.createElement('button');
              b.id = 'fakesubmit'; b.textContent = 'Submit';
              b.onclick = () => { window.__submitted = true; };
              document.body.appendChild(b);
              document.getElementById('examguard-host').remove();
              document.body.inert = false;
              b.click();
              return window.__submitted;
            }""")
            check("lock holds against DevTools removal (click blocked)", bypass is False, str(bypass))
            await asyncio.sleep(0.6)
            st = await state()
            check("still locked after bypass attempt", sessions(st) == [("locked", 3)], sessions(st))
            check("overlay restored after tampering", await exam.locator("text=Your exam is paused").count() > 0)
            check("tampered input is logged", any(e["type"] == "input_while_blocked" for e in st["events"]))
            await exam.evaluate("document.getElementById('fakesubmit')?.remove()")

            # Teacher unlock
            await dev({"type": "DEV_UNLOCK", "attemptId": st["sessions"][0]["id"]})
            await asyncio.sleep(1.5)
            st = await state()
            check("unlock -> active, strikes max-1", sessions(st) == [("active", 2)], sessions(st))
            check("locked screen removed", await exam.locator("text=Your exam is paused").count() == 0)

            rules = await pop.evaluate("() => chrome.declarativeNetRequest.getSessionRules()")
            check("AI blocklist rules active", any(x["condition"]["urlFilter"] == "||chatgpt.com^" for x in rules), len(rules))

            await exam.evaluate("document.dispatchEvent(new ClipboardEvent('copy', {cancelable:true, bubbles:true}))")
            await asyncio.sleep(.6)
            st = await state()
            check("copy attempt logged", any(e["type"] == "copy_attempt" for e in st["events"]))

            await exam.goto(FORM_DONE); await asyncio.sleep(1)
            st = await state()
            rules = await pop.evaluate("() => chrome.declarativeNetRequest.getSessionRules()")
            check("submit ends session", len(st["sessions"]) == 0)
            check("submit removes block rules", len(rules) == 0, len(rules))
        finally:
            await ctx.close()
            shutil.rmtree(tmp, ignore_errors=True)

    print(f"\n{'ALL PASSED' if not failures else f'{len(failures)} FAILED: ' + ', '.join(failures)}")
    sys.exit(1 if failures else 0)

asyncio.run(main())
