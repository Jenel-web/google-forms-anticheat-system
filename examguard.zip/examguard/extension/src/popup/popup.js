// Dev panel: stands in for the teacher dashboard until Supabase is wired up (step 2/3).

const $ = (id) => document.getElementById(id);
const send = (msg) => chrome.runtime.sendMessage(msg);
let lockedAttempt = null;

function fmt(e) {
  const time = new Date(e.t).toLocaleTimeString();
  const extra = [e.reason, e.domain, e.strikes != null ? `strikes=${e.strikes}` : null, e.ms ? `${Math.round(e.ms / 1000)}s` : null]
    .filter(Boolean).join(' ');
  return `${time}  ${e.type}${extra ? ' · ' + extra : ''}${e.q ? ` · Q${e.q.i}/${e.q.n}` : ''}`;
}

async function refresh() {
  const st = await send({ type: 'DEV_STATE' });
  const s = st.sessions[0];
  const status = $('status');
  lockedAttempt = null;
  if (!s) {
    status.className = 'status';
    status.textContent = 'Not on a protected exam.';
  } else {
    status.className = 'status ' + (s.phase === 'locked' ? 'locked' : 'on');
    status.textContent = `${s.student.name} (${s.student.email}${s.student.verified ? ' ✓' : ', unverified'}) · ${s.phase} · strikes ${s.strikes}/${s.maxStrikes}`;
    if (s.phase === 'locked') lockedAttempt = s.id;
  }
  $('unlock').disabled = !lockedAttempt;

  $('tests').textContent = st.tests.length ? 'Protected: ' + st.tests.map((t) => t.title).join(', ') : 'No protected forms yet.';
  const ul = $('events');
  ul.replaceChildren();
  if (!st.events.length) {
    const li = document.createElement('li'); li.className = 'muted'; li.textContent = 'No events yet.'; ul.append(li);
  }
  st.events.forEach((e) => { const li = document.createElement('li'); li.textContent = fmt(e); ul.append(li); });
}

$('add').addEventListener('click', async () => {
  const r = await send({ type: 'DEV_ADD_TEST', url: $('url').value.trim(), title: $('title').value.trim() });
  $('msg').textContent = r.error || 'Protected! Open the form link to start.';
  $('msg').style.color = r.error ? '#d93025' : '#188038';
  refresh();
});
$('unlock').addEventListener('click', async () => {
  if (lockedAttempt) await send({ type: 'DEV_UNLOCK', attemptId: lockedAttempt });
  setTimeout(refresh, 300);
});
$('reset').addEventListener('click', async () => { await send({ type: 'DEV_RESET' }); refresh(); });

refresh();
setInterval(refresh, 2000);
